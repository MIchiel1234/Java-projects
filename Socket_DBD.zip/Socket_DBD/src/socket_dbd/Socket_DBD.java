/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socket_dbd;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.net.ssl.SSLServerSocket;

/**
 *
 * @author user
 */
public class Socket_DBD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, SQLException, ClassNotFoundException {
     
        ServerSocket ss  = new ServerSocket(5432);
        Socket s = ss.accept();
        
      ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
//        ArrayList<Student> as  = (ArrayList<Student>)ois.readObject();
     String sw=(String)ois.readObject();
     System.out.println("Succesfully Inserted");
//        for (Student item : as) {
//            Datahandler dh = new Datahandler();
//            dh.Insert(new Student(item.id, item.name, item.surname, item.mark));
//            System.out.println("Succesfully Inserted");
//        }
      
        Datahandler dh = new Datahandler();
           ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
        ArrayList<Student> as2 =  dh.Display();
       
         for (Student item : as2) {
             System.out.println(item.mark);
}     
         oos.writeObject(as2);
       // oos.flush();
        
        
        
        
    }
    
    
}
