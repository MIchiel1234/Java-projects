/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socket_dbd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Datahandler {
    
    
    public Connection connect_db() throws SQLException, ClassNotFoundException
    {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/socket_db","root","");
    
    return con;
    }
    
    public void Insert(Student s) throws SQLException, ClassNotFoundException
    {
    Connection con = connect_db();
    PreparedStatement ps = con.prepareStatement("INSERT INTO `student`(`ID`, `Name`, `Surname`, `Mark`) VALUES (NULL,?,?,?)");
    ps.setString(1, s.name);
    ps.setString(2, s.surname);
    ps.setDouble(3, s.mark);
    ps.executeUpdate();
    }
    
    public ArrayList<Student> Display() throws SQLException, ClassNotFoundException
    {
    Connection con = connect_db();
    ArrayList<Student> as = new ArrayList<>();
    Statement st = con.createStatement();
    ResultSet rs = st.executeQuery("Select * from Student");
        while (rs.next()) {            
            int id = rs.getInt(1);
            String name = rs.getString("Name");
            String surname = rs.getString("Surname");
            double mark = rs.getDouble("Mark");
            
            as.add(new Student(id, name, surname, mark));
        }
    return as;
    }
}
