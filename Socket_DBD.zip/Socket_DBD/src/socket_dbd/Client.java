/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socket_dbd;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class Client {

    /**
     * @param args the command line arguments
     */
    public enum Menu
    {
    Insert, Display, Exit;
    }
    
    private final static int Insert = 1;
    private final static int Display = 2;
    private final static int Exit = 3;
    
    
     
    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        // TODO code application logic here
        
        System.out.println("-----------Menu------------");
        System.out.println("===========================");
        System.out.println("1. Insert");
        System.out.println("2. Display");
        System.out.println("3. Exit");
        
        Scanner sc = new Scanner(System.in);
        int opt = sc.nextInt();
        Menu m=Menu.values()[opt-1];
        switch(m)
        {
            case Insert:
                InsertDB();
                break;
            case Display:
                DisplayDB();
                break;
            case Exit:
                System.exit(0);
                break;
        
        }
        
    }
    
    public static void DisplayDB() throws IOException, ClassNotFoundException
    {
         Socket s = new Socket("localhost",5432);
        Scanner sc = new Scanner(System.in);
      
        ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
       oos.writeObject("Sending");
     ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
      ArrayList<Student> as2 = (ArrayList<Student>)ois.readObject();
       
        for (Student item : as2) {
            System.out.println(item.toString());
       }

    }
    
    
    public static void InsertDB() throws IOException
    {
       
//        Scanner sc = new Scanner(System.in);
//     Socket s = new Socket("localhost",5432);
//        
//        System.out.println("Enter Name:");
//        String name = sc.next();
//        System.out.println("Enter Surname:");
//        String surname = sc.next();
//        System.out.println("Enter Mark");
//        double mark = sc.nextDouble();
//        
//        ArrayList<Student> as = new ArrayList<>();
//        as.add(new Student(0, name, surname, mark));
//        
//        ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
//        
//        oos.writeObject(as);
//        oos.flush();
    }
    
}
