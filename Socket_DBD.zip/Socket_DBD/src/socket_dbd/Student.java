/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package socket_dbd;

import java.io.Serializable;

/**
 *
 * @author user
 */
public class Student implements Serializable{
    
    int id;
    String name, surname;
    double mark;

    public Student(int id, String name, String surname, double mark) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.mark = mark;
    }

    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", surname=" + surname + ", mark=" + mark + '}';
    }
    
    
}
